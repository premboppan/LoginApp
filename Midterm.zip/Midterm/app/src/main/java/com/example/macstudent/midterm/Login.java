package com.example.macstudent.midterm;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;

import java.util.Random;

public class Login extends AppCompatActivity {

    private ImageView i1;
    private ImageView i2;
    private ImageView i3;
    private ImageView i4;
    private ImageView i5;
    private ImageView i6;
    private ImageView i7;
    private ImageView i8;
    private ImageView i9;
    private Button button;
    private CheckBox checkBox;
    private ImageView i10;
    private AlertDialog alertDialog;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        i1 = findViewById(R.id.imageView1);
        i2 = findViewById((R.id.imageView2));
        i3 = findViewById(R.id.imageView3);
        i4 = findViewById(R.id.imageView4);
        i5 = findViewById(R.id.imageView5);
        i6  = findViewById(R.id.imageView6);
        i7 = findViewById(R.id.imageView7);
        i8 = findViewById(R.id.imageView8);
        i9 = findViewById(R.id.imageView9);
        button = findViewById(R.id.buttontoverify);
        checkBox = findViewById(R.id.checkBox);
        i10 = findViewById(R.id.refresh);



    }
    ver




    }

    public void dropIn(View view) {
        ImageView counter = (ImageView) view;
        counter.setImageResource(R.drawable.checked);

    }
     public int generateRandomImg() {
         Random random = new Random();
         int randomNum = random.nextInt(imageGroup.length);
         return randomNum;

     }

     public void verifiedalert(){
         AlertDialog alertDialog = new AlertDialog(this),create();
         alertDialog.setMessage("Verified");
         alertDialog.setButton();

     }
}
